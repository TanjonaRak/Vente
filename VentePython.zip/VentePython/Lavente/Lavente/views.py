from django.shortcuts import render
from django.http import HttpResponse
from Lavente.TEST.Admin import Admin
from Lavente.TEST.Produit import Produit
from Lavente.TEST.LaVenteProd import LaVenteProd
from Lavente.TEST.LaVenteProd import LaVenteProd
from django.template import loader

def index(request):
    f = "ff"
    return render(request, 'index.html', context={"h": f})
def logclient(request):
	 return render(request, 'logclient.html')
def logadmin(request):
	 return render(request,'logadmin.html')	
def traitelog(request):
	prenom=request.POST['prenom']
	mdp=request.POST['mdp']
	admin=Admin()
	#LVP=LaVenteProd()
	tabl="Client"
	val=admin.login(prenom,mdp,tabl)

	if val==0 :
		return render(request,'logclient.html')
	else:
		request.session['idclient']=val
		LVP=LaVenteProd()
		lsLVProd=LVP.getLavente()
		LSVT=LVP.LISTEVENTEVITE(val)
		return render(request,'listeEC.html',context={'ls_Lavente':lsLVProd,'lsvita':LSVT})
	#return HttpResponse(prenom)
def listeprod(request):
	prod=Produit()
	lsProd=prod.getproduit()
	return render(request,'listeprod.html',context={"prod":lsProd})
#def AjoutVente	
def fairevente(request):
	LVP=LaVenteProd()
	LSVT=LVP.LISTEVENTEVITE(0)
	idprod=request.GET['idprod']
	return render(request,'FaireVente.html',context={"idprod":idprod,'lsvita':LSVT})
def AjoutLVT(request):
	idprod=request.POST['idprod']
	dtD=request.POST['dateD']
	dtF=request.POST['dateF']
	LVP=LaVenteProd()
	LVP.faireLavente(idprod,dtD,dtF)
	return render(request,'index.html')
def VoirLVProd(request):
	LVP=LaVenteProd()
	lsLVProd=LVP.getLavente()
	LSVT=LVP.LISTEVENTEVITE(0)
	return render(request,'listeEC.html',context={"ls_Lavente":lsLVProd,'lsvita':LSVT})
def offre(request):
	idclient=request.session['idclient']
	LVP=LaVenteProd()
	testcli=LVP.getSUSP(int(idclient))
	if testcli!=None:
		error="SUSPENDU ENAO EH"
		LVP=LaVenteProd()
		lsLVProd=LVP.getLavente()
		LSVT=LVP.LISTEVENTEVITE(idclient)
		return render(request,'listeEC.html',context={'error':error,'ls_Lavente':lsLVProd,'lsvita':LSVT})
	else:
		idprod=request.GET['idprod']
		LVP=LaVenteProd()
		ls=LVP.listeAJ(idprod)
		return render(request,'offre.html',context={"idprod":idprod,'ls':ls})
def fairevente2(request):
	idprod=request.POST['idprod']
	idclient=request.session['idclient']
	prix=request.POST['prix']
	LVP=LaVenteProd()
	test=LVP.testPrix(idprod,int(prix),idclient)
	ls=LVP.listeAJ(idprod)
	test2="avereno"
	if test==0:
		template=loader.get_template('offre.html')
		context={'error':"METY",'idprod':idprod,'ls':ls}
		return HttpResponse(template.render(context,request))
	if test==1:
		return render(request,'offre.html',context={'error':"Kely no IRAY",'idprod':idprod,'ls':ls})
	if test==2:
		return render(request,'offre.html',context={'error':"vita encher",'idprod':idprod,'ls':ls})
	#else:
		#return render(request,'offre.html',context={'error':"avereno eh",'idprod':idprod,'ls':ls})

	#rqt="select max(prix) from VenteEC where idLaVenteProd='"+idprod+"'"
	return HttpResponse(test2)
def vita(request):
	idVenteEC=request.GET['idvt']
	idclient=request.session['idclient']
	LVP=LaVenteProd()
	LVP.vitavente(idVenteEC)
	LVP=LaVenteProd()
	lsLVProd=LVP.getLavente()
	LSVT=LVP.LISTEVENTEVITE(idclient)
	return render(request,'listeEC.html',context={'idclient':idclient,'ls_Lavente':lsLVProd,'lsvita':LSVT})
def desist(request):
	idclient=request.session['idclient']
	idlvp=request.GET['idprod']
	LVP=LaVenteProd()
	ls=LVP.prodesist(idclient)
	return render(request,'choixdesist.html',context={'idprod':idlvp,'ls':ls})
def adduser(request):
	return render(request,'Adduser.html')
def ls_suspend(request):
	LVP=LaVenteProd()
	liste=LVP.getsuspend()
	return render(request,'listesus.html',context={'liste':liste})
def desusp(request):
	idsuscl=request.GET['idcl']
	LVP=LaVenteProd()
	LVP.desuspV(idsuscl)
	return render(request,'index.html')
	#rqt="update suspendu set etat=1 where idclient="+idsuscl
def adduser2(request):
	prenom=request.POST['prenom']
	mdp=request.POST['mdp']
	ncpt=request.POST['ncpt']
	LVP=LaVenteProd()
	error=LVP.AjoutUser(prenom,mdp,ncpt)
	return render(request,'Adduser.html',context={'error':error})
	#return HttpResponse(error)
def desistall(request):
	idclient=request.session['idclient']
	#idlvp=request.GET['idvt2']
	LVP=LaVenteProd()
	LVP.FaireDesist(str(idclient))
	return render(request,'index.html')
def desist1(request):
	idclient=request.session['idclient']
	idprod=request.POST['idprod']
	vola=request.POST['vola']
	LVP=LaVenteProd()
	if int(vola) >= 300:
		LVP.desist1(str(idclient),str(idprod))
		error="DESIST1 ACCEPTE "
		return render(request,'logclient.html',context={'error':error})
	else:
		error="vola narotsakao ="+vola+" izay Kely 300"
		return render(request,'choixdesist.html',context={'error':error,'idprod':idprod})
def NONdesist(request):
	LVP=LaVenteProd()
	idclient=request.session['idclient']
	idprod=request.POST['idprod']
	return render(request,'montant.html',context={'idclient':idclient,'idprod':idprod})
	#LVP.prodesist(idclient,idprod)
def non(request):
	idprod=request.GET['idprodn']
	idclient=request.session['idclient']
	prix=request.GET['prix']
	return render(request,'montant.html',context={'idclient':idclient,'idprodn':idprod,'prix':prix})
def desist11(request):
	idclient=request.session['idclient']
	idprod=request.POST['idprod']
	vola=request.POST['vola']
	LVP=LaVenteProd()
	print(float(vola)*0.1)
	if float(vola)==float(vola)*0.1:
		LVP.METY(idclient,idLaVenteProd)
		LVP=LaVenteProd()
		lsLVProd=LVP.getLavente()
		LSVT=LVP.LISTEVENTEVITE(idclient)
		return render(request,'listeEC.html',context={'error':error,'ls_Lavente':lsLVProd,'lsvita':LSVT})
	else:
		return render(request,'montant.html',context={'idclient':idclient,'idprodn':idprod,'prix':vola,'error':"tsy mety le vola"})











		









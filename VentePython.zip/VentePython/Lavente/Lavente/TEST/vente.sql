create table admine(
    idadmin int not null identity primary key, 
    prenom varchar(20),
    mdp varchar(20)
)
go

create table produit(
    idproduit int identity primary key,
    nomp varchar(20),
    prixN double precision,
    prixPl double precision
)
go


create table client(
    idclient int not null identity primary key,
    prenom varchar(20),
    mdp varchar(20),
    Ncompte varchar(30) unique
) 
go

create table LaVenteProd(
    idLaVenteProd int not null identity primary key,
    idproduit int,
    dtHeureD datetime default current_timestamp,
    dtHeureF datetime,
    constraint fk_prod22 foreign key (idproduit) references produit(idproduit)
)
go

create table testDate(
     dtHeureD datetime
)
go

create table clientSUSP(
    idclisusp int not null identity primary key,
    idclient int ,
    dateDSUS datetime default current_timestamp,
    constraint fk_clv22 foreign key (idclient) references client(idclient)
)

create table venteECV(
    idventeEC int not null identity primary key,
    idclient int,
    idLaVenteProd int,
    prix double precision,
    Hdebut datetime default current_timestamp,
    etatEcher int default 0,
    etatDesist int default 0, 
    constraint fk_clv foreign key (idclient) references client(idclient),
    constraint fk_lvPrv foreign key (idLaVenteProd) references LaVenteProd(idLaVenteProd)
)
go

create table prodP(
    id int not null identity primary key,
    idLaVenteProd int,
    idclient int,
    constraint fk_c foreign key (idclient) references client(idclient),
    constraint fk_l foreign key (idLaVenteProd) references LaVenteProd(idLaVenteProd)
)


create table suspendu(
    idsusp int not null identity primary key,
    idclient int,
    etat int default 0,
    constraint fk_clv2 foreign key (idclient) references client(idclient)
)

create table VenteVitaV22(
    idVenteVita int not null identity primary key ,
    idventeEc int,
    constraint fk_vecV22 foreign key (idventeEC) references VenteECV(idventeEC)
)
go

///****create table ***///

//////////////////////////********************************************///////////////////////////////////

///////*les donnees de test et les differentes view*///////


insert into client(prenom,mdp,Ncompte)values('pre','nom','1234')
insert into client(prenom,mdp,Ncompte)values('zaty','11','12345')
insert into admine (prenom,mdp)values('ts','123')
go
insert into produit (nomp,prixN,prixPl) values ("tele",120.0,300.3)
insert into produit (nomp,prixN,prixPl) values ("radio",100.0,205.3)
insert into produit (nomp,prixN,prixPl) values ("frigo",500.0,700.3)
insert into produit (nomp,prixN,prixPl) values ("mofo",120.0,300.3)
go



 select p.nomp,p.prixN,p.prixPl,lv.dtHeureD,lv.dtHeureF 
 from produit as p,LaVenteProd as lv where p.idproduit=lv.idproduit
 go

 select * from produit where idproduit not in (select idproduit from LaVenteProd)
 go

 create view LV_PROD as()

 select * from LaVenteProd as lvp,produit as pr
 where lvp.idproduit=pr.idproduit
 go   

 create view LS_lavente as(
    select lvp.idLaVenteProd,lvp.idproduit,lvp.dtHeureD,lvp.dtHeureF,pr.nomp,pr.prixN,pr.prixPl from 
    LaVenteProd as lvp,produit as pr where lvp.idproduit=pr.idproduit)

 select * from VenteECV where idventeEC not in
 (select idventeEC from desist) order by prix Desc

 select * from VenteECV where etatEcher=0 order by prix desc 
 go

 select prod.nomp from LaVenteProd as lv , produit prod 
 where lv.idproduit=prod.idproduit and lv.idLaVenteProd='2'

 select * from VenteECV where etatEcher='1' order by prix desc

 create view Vente_VT as(select prod.nomp,lv.prix,cli.prenom,lv.Hdebut,lv.idclient,lprod.idLaVenteProd,lv.idventeEC 
 from VenteECV lv,LaVenteProd lprod,client cli,produit prod
 where lv.idclient=cli.idclient and lv.idLaVenteProd=lprod.idLaVenteProd and prod.idproduit=lprod.idproduit
 and lv.prix=(select max(prix) from VenteECV where etatEcher='1' and etatDesist='0'))
 go

 create view VenteAJ as(select prod.nomp,lv.prix,cli.prenom,lv.Hdebut,lv.idclient,lprod.idLaVenteProd,lv.idventeEC 
 from VenteECV lv,LaVenteProd lprod,client cli,produit prod
 where lv.idclient=cli.idclient and lv.idLaVenteProd=lprod.idLaVenteProd and prod.idproduit=lprod.idproduit
 and lv.etatDesist!=0
 and lv.prix=(select max(prix) from VenteECV where etatEcher='0' and etatDesist='0'))


 select cl.prenom from suspendu as sus,client as cl
 where sus.idclient=cl.idclient
 go

create view Vente_VT222 as(
select prod.nomp,lv.prix,cli.prenom,lv.Hdebut,lv.idclient,lprod.idLaVenteProd,lv.idventeEC
from VenteECV lv,LaVenteProd lprod,client cli,produit prod
where lv.idclient=cli.idclient and lv.idLaVenteProd=lprod.idLaVenteProd and prod.idproduit=lprod.idproduit 
and etatEcher=1 and etatDesist =0  
and lv.prix 
in (select max(prix) from VenteECV where etatEcher='1' and etatDesist='0' group by idLaVenteProd )
)
go

/*select prod.nomp,lv.prix,cli.prenom,lv.Hdebut,lv.idclient,lprod.idLaVenteProd,lv.idventeEC
from VenteECV lv,LaVenteProd lprod,client cli,produit prod
where lv.idclient=cli.idclient and lv.idLaVenteProd=lprod.idLaVenteProd and prod.idproduit=lprod.idproduit 
and etatEcher=1 and etatDesist =1 
and cli.idclient=1

select max(prix),idLaVenteProd from VenteECV group by idLaVenteProd

 and idclient not in (select idclient from suspendu where etat=0)*/



insert into produit (nomp,prixN,prixPl) values ("ORDI1",1200.0,30000.3)
insert into produit (nomp,prixN,prixPl) values ("ANANA",1000.0,2050.3)
insert into produit (nomp,prixN,prixPl) values ("WISKI2",5000.0,7000.3)
insert into produit (nomp,prixN,prixPl) values ("CHRISTALINA",120.0,300.3)
go
create view prix_NON as(select max(prix),idLaVenteProd from VenteECV  where  idclient=1 group by idLaVenteProd)

    

/*select LS_lavente.nomp from VenteECV join LS_lavente on
VenteECV.idLaVenteProd=LS_lavente.idLaVenteProd where 
etatEcher=0  group by VenteECV.idLaVenteProd 
go

select max(prix),nomp from VenteAJ where idclient=1 group by idLaVenteProd

select max(prix),idLaVenteProd from VenteECV where idclient=1 and etatEcher=0 group by idLaventeprod*/
 







import datetime
from Lavente.TEST.AccessData import connect


class LaVenteProd:
	idLaVenteProd=0
	idproduit=0
	nomP=str()
	prixN=0.0
	prixPl=0.0
	dateD=str()
	dateF=str()
	def faireLavente(self,idproduit,dateD,dateF):
		dateD_obj=datetime.datetime.strptime(dateD,'%Y-%m-%d %H:%M:%S')
		dateF_obj=datetime.datetime.strptime(dateF,'%Y-%m-%d %H:%M:%S')
		rqt="insert into LaVenteProd(idproduit,dtHeureD,dtHeureF)values("+idproduit+",'"+str(dateD_obj)+"','"+str(dateF_obj)+"')"
		con=connect()
		connection=con.connecter()
		cursor=connection.cursor()
		cursor.execute(rqt)
		cursor.commit()
	def getLavente(self):
		rqt="select * from LS_lavente where idLaVenteProd not in (select idLaVenteProd from VenteECV where etatEcher=1) "
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		return curs
	def testPrix(self,idLaVenteProd,prix,idclient):
		rqt="select max(prix) from VenteECV where idLaVenteProd='"+idLaVenteProd+"'"
		#rqt3="select prixPl from LaVenteProd as lv,produit as prod where LaVenteProd.idproduit=prod.idproduit and LaVenteProd.idLaVenteProd='"+idLaVenteProd+"'"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		#curs.close()
		LVP=LaVenteProd()
		test=LVP.getPrixActu(idLaVenteProd)
		prixPl=LVP.getprixPL(idLaVenteProd)
		rqt2="insert into VenteECV(idclient,idLaVenteProd,prix)values('"+str(idclient)+"','"+str(idLaVenteProd)+"','"+str(prix)+"')"
		if test==None and prix<prixPl:
			curs=connection.cursor()
			curs.execute(rqt2)
			curs.commit()
			return 0
		if prix<prixPl and prix>test:
			curs=connection.cursor()
			curs.execute(rqt2)
			curs.commit()
		else:
			if test>=prix:
				return 1
			if prixPl<=prix:
				LVP.exec(rqt2)
				LVP.update(idLaVenteProd)
				return 2
		#return LVP.getPrixActu(idLaVenteProd)		
	def getprixPL(self,idLaVenteProd):
		rqt="select prixPl from LaVenteProd as lv,produit as prod where lv.idproduit=prod.idproduit and lv.idLaVenteProd='"+idLaVenteProd+"'"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		for row in curs:
			return row[0]
	def update(self,idLaVenteProd):
		date=datetime.datetime.now()
		dateV=date.strftime('%y-%m-%d %H:%M:%S')
		print(dateV)
		rqt="update VenteECV set etatEcher=1 where idLaVenteProd='"+idLaVenteProd+"'"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		curs.commit()
		#return rqt
	def getPrixActu(self,idLaVenteProd):
		rqt="select max(prix) from VenteECV where idLaVenteProd='"+idLaVenteProd+"'"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		for row in curs:
			return row[0]
	def NOMPROD(self,idLaVenteProd):
		rqt="select prod.nomp from LaVenteProd as lv , produit prod where lv.idproduit=prod.idproduit and lv.idLaVenteProd='"+idLaVenteProd+"'"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		for row in curs:
			return row[0]
	def LISTEVENTEVITE(self,idclient):
		if idclient!=0:
			rqt="select * from  Vente_VT222 where idclient='"+str(idclient)+"' and idVenteEC not in (select idVenteEC from VenteVitaV22)"
		if idclient==0:
			rqt="select * from  Vente_VT222 where  idVenteEC not in (select idVenteEC from VenteVitaV22) "
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		return curs
	def vitavente(self,idVenteEC):
		rqt="insert into VenteVitaV22(idVenteEC)values('"+str(idVenteEC)+"')"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		curs.commit()
	def listeAJ(self,idLaVenteProd):
		rqt="select * from VenteAJ where idLaVenteProd='"+idLaVenteProd+"' and idVenteEC not in (select idVenteEC from VenteVitaV22)"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		return curs
	def FaireDesist(self,idclient):
		rqt="update VenteECV set etatDesist=1 where idclient='"+idclient+"'"
		LVP=LaVenteProd()
		LVP.insertSusp(idclient)
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		curs.commit()
	def insertSusp(self,idclient):
		rqt="insert into suspendu (idclient)values('"+str(idclient)+"')"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		curs.commit()
	def exec(self,rqt):
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		curs.commit()
	def testUser(self,ncpt):
		rqt="select count(*) from client where Ncompte='"+ncpt+"'"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		for row in curs:
			return row[0]
	def AjoutUser(self,prenom,mdp,ncpt):
		LVP=LaVenteProd()
		test=LVP.testUser(ncpt)
		rqt="insert into client (prenom,mdp,Ncompte)values('"+prenom+"','"+mdp+"','"+ncpt+"')"
		if test==0:
			con=connect()
			connection=con.connecter()
			curs=connection.cursor()
			curs.execute(rqt)
			curs.commit()
			return "OK izy eh"
		else:
			return "error votre compte Bankaire"
	def getsuspend(self):
		rqt="select * from suspendu as sus,client as cl where sus.idclient=cl.idclient and etat=0"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		return curs
	def desuspV(self,idclient):
		rqt="update suspendu set etat=1 where idclient="+idclient
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		curs.commit()
	def getSUSP(self,idclient):
		rqt="select idclient from suspendu where etat=0 and idclient='"+str(idclient)+"'"
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		for row in curs:
			return row[0]
	def desist1(self,idclient,idLaVenteProd):
		rqt="update VenteECV set etatDesist=1 where idclient='"+idclient+"' and idLaVenteProd='"+idLaVenteProd+"'"
		print(rqt)
		LVP=LaVenteProd()
		#LVP.insertSusp(idclient)
		con=connect()
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		curs.commit()
	def prodesist(self,idclient):
		rqt="select max(prix) as prix,idLaVenteProd from VenteECV  where idclient='"+str(idclient)+"' and etatEcher=0  group by idLaVenteProd"
		con=connect()
		print(rqt)
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		return curs
	def METY(self,idclient,idLaVenteProd):
		rqt="insert into prodP (idclient,idLaVenteProd)values('"+idclient+"','"+idLaVenteProd+"')"
		con=connect()
		print(rqt)
		connection=con.connecter()
		curs=connection.cursor()
		curs.execute(rqt)
		curs.commit()









			














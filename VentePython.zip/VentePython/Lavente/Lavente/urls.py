"""Lavente URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Lavente.views import index
from Lavente.views import logclient
from Lavente.views import logadmin
from Lavente.views import traitelog
from Lavente.views import listeprod
from Lavente.views import fairevente
from Lavente.views import AjoutLVT
from Lavente.views import VoirLVProd
from Lavente.views import offre
from Lavente.views import fairevente2
from Lavente.views import vita
from Lavente.views import desist
from Lavente.views import adduser
from Lavente.views import ls_suspend
from Lavente.views import desusp
from Lavente.views import adduser
from Lavente.views import adduser2
from Lavente.views import desistall
from Lavente.views import desist1
from Lavente.views import non
from Lavente.views import desist11

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/',index),
    path('logclient/',logclient),
    path('logadmin/',logadmin),
    path('traitelog/',traitelog),
    path('lsprod/',listeprod),
    path('vente/',fairevente),
    path('ajout/',AjoutLVT),
    path('ls_lavente/',VoirLVProd),
    path('offre/',offre),
    path('fairevente2/',fairevente2),
    path('vita/',vita),
    path('desist/',desist),
    path('adduser/',adduser),
    path('ls_suspend/',ls_suspend),
    path('Desusp/',desusp),
    path('adduser2/',adduser2),
    path('vraidesist/',desistall),
    path('desist1/',desist1),
    path('non/',non),
    path('desist11/',desist11)

]

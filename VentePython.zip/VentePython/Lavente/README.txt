==>ouvrire le fichier vente.sql et lancez votre sql server et copier tous les scriptes dans le vente.sql dans le cmd de sql server
==>framework django  
import Admin

class Client:
	idClient=""
	prenom=""
	mdp=""
	
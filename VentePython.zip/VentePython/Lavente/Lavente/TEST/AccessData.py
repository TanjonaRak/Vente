import pyodbc
class connect:
    def connecter(self):
        conn=pyodbc.connect("Driver={SQL Server};Server=DESKTOP-2402EPH\SQLEXPRESS;Database=vente2;Trusted_Connection=yes;")
        curs=conn.cursor()
        print("ok")
        return conn
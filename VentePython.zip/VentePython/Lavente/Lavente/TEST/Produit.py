from Lavente.TEST.AccessData import connect
class Produit :
    idprod=0
    nomp=str()
    prixN=0.0
    prixPl=0.0
    def getproduit(self):
        con=connect()
        con=con.connecter()
        rqt="select * from produit where idproduit not in (select idproduit from LaVenteProd) "
        curs=con.cursor()
        curs.execute(rqt)
        List=[]
        for row in curs:
            prod=Produit()
            prod.idprod=row[0]
            prod.nomp=row[1]
            prod.prixN=row[2]
            prod.prixPl=row[3]
            List.append(prod)
        return List        	
    #def faireLavente(self,idprod,dateD,dateF)    	
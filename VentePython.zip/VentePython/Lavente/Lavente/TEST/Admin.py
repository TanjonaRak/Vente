from Lavente.TEST.AccessData import connect
#con = connecter()
class Admin :
    idadmin=""
    prenom="" 
    mdp=""  
    def login(self,nom,mdp,tabl):
        acc=connect()
        con=acc.connecter()
        #()
        rqt="select * from "+tabl+" where prenom='"+nom+"' and mdp='"+mdp+"'"
        curs=con.cursor()
        res=curs.execute(rqt)
        rep=0
        for res2 in res:
            List=f'{res}'
            if List=='null':
                rep=0
            else:
                rep=res2[0]
        return rep  